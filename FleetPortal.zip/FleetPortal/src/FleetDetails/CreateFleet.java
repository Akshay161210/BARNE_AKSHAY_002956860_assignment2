/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FleetDetails;

/**
 *
 * @author Akshay Barne
 */
public class CreateFleet {
    private String Manufacturer;
    private String CarName;
    private String Model;
    private int ManufacturingYear;
    private String Location;
    private String SerialNo;
    private int MinSeats;
    private int MaxSeats;
    private String VehicleCerticateNumber;
    private boolean Availability_Yes;
    private boolean Certificate_Expired;
    
    public String getManufacturer() {
        return Manufacturer;
    }

    public void setManufacturer(String Manufacturer) {
        this.Manufacturer = Manufacturer;
    }

    public String getCarName() {
        return CarName;
    }

    public void setCarName(String CarName) {
        this.CarName = CarName;
    }
    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public int getManufacturingYear() {
        return ManufacturingYear;
    }

    public void setManufacturingYear(int ManufacturingYear) {
        this.ManufacturingYear = ManufacturingYear;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public String getSerialNo() {
        return SerialNo;
    }

    public void setSerialNo(String SerialNo) {
        this.SerialNo = SerialNo;
    }

    public int getMinSeats() {
        return MinSeats;
    }

    public void setMinSeats(int MinSeats) {
        this.MinSeats = MinSeats;
    }

    public int getMaxSeats() {
        return MaxSeats;
    }

    public void setMaxSeats(int MaxSeats) {
        this.MaxSeats = MaxSeats;
    }

    public String getVehicleCerticateNumber() {
        return VehicleCerticateNumber;
    }

    public void setVehicleCerticateNumber(String VehicleCerticateNumber) {
        this.VehicleCerticateNumber = VehicleCerticateNumber;
    }
    public boolean isAvailability_Yes() {
        return Availability_Yes;
    }

    public void setAvailability_Yes(boolean Availability_Yes) {
        this.Availability_Yes = Availability_Yes;
    }

    public boolean isCertificate_Expired() {
        return Certificate_Expired;
    }

    public void setCertificate_Expired(boolean Certificate_Expired) {
        this.Certificate_Expired = Certificate_Expired;
    }
    @Override
    public String toString(){
        return Manufacturer;
    }
}
