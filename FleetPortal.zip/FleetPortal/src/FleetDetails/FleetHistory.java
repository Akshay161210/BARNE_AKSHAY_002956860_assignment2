/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FleetDetails;

import java.util.ArrayList;

/**
 *
 * @author Akshay Barne
 */
public class FleetHistory {
    private ArrayList<CreateFleet>FleetData; 
    
    public FleetHistory(){
        this.FleetData = new ArrayList<CreateFleet>();  
    }

    public ArrayList<CreateFleet> getFleetData() {
        return FleetData;
    }

    public void setFleetData(ArrayList<CreateFleet> FleetData) {
        this.FleetData = FleetData;
    }
    
    public CreateFleet addNewFleet(){
        CreateFleet newFleet = new CreateFleet();
        FleetData.add(newFleet);
        return newFleet;
    }
    
    public void deleteFleet(CreateFleet cf){
        FleetData.remove(cf);
    }
    
}
