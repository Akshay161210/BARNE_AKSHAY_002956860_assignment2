/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

import FleetDetails.CreateFleet;
import FleetDetails.FleetHistory;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFileChooser;


/**
 *
 * @author Akshay Barne
 */
public class ReadCSV {
    
    FleetHistory FleetData;
    
    public ReadCSV(FleetHistory FleetData)
    {
        this.FleetData=FleetData;
    }


public void bulkLoad(){
String line = "";
String splitBy = ",";


UtilFunction util = new UtilFunction();
try{
BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Admin\\Documents\\Car_Fleet_Info.csv"));
while ((line = br.readLine())!= null)
{
String[] Fleet = line.split(splitBy);

            String Manufacturer = Fleet[0];
            String CarName = Fleet[1];
            String Model = Fleet[2];
            String SerialNo = Fleet[3];
            int ManufacturingYear = Integer.parseInt(Fleet[4]);
            int MinSeats = Integer.parseInt(Fleet[5]);
            int MaxSeats = Integer.parseInt(Fleet[6]);
            String Location = Fleet[7];
            String VehicleCerticateNumber = Fleet[8];
            boolean Availability_Yes = Fleet[9].equals("Yes");
            boolean Certificate_Expired = Fleet[10].equals("Expired");
            
            
            CreateFleet newFleet = FleetData.addNewFleet();
            newFleet.setManufacturer(Manufacturer);
            newFleet.setCarName(CarName);
            newFleet.setModel(Model);
            newFleet.setSerialNo(SerialNo);
            newFleet.setManufacturingYear(ManufacturingYear);
            newFleet.setMinSeats(MinSeats);
            newFleet.setMaxSeats(MaxSeats);
            newFleet.setLocation(Location);
            newFleet.setVehicleCerticateNumber(VehicleCerticateNumber);
            newFleet.setAvailability_Yes(Availability_Yes);
            newFleet.setCertificate_Expired(Certificate_Expired);
}
}
catch(IOException e)
{
    e.printStackTrace();
            
}

}

}