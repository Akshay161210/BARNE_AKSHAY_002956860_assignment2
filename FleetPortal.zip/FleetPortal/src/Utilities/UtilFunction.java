/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

import FleetDetails.CreateFleet;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Akshay Barne
 */
public class UtilFunction {
    
    public void populateTablebyList(ArrayList<CreateFleet> list, JTable TblFleetDetails){
        DefaultTableModel model = (DefaultTableModel)TblFleetDetails.getModel();
        model.setRowCount(0);
        
        for(CreateFleet cf: list){
            Object[] row = new Object[11];
            row[0] = cf;
            row[1] = cf.getCarName();
            row[2] = cf.getModel();            
            row[3] = cf.getSerialNo();
            row[4] = cf.getManufacturingYear();
            row[5] = cf.getMinSeats();
            row[6] = cf.getMaxSeats();
            row[7] = cf.getLocation();
            row[8] = cf.getVehicleCerticateNumber();
            if (cf.isAvailability_Yes() == true){
                cf.setAvailability_Yes(true);
                row[9] = "Yes";
            }else{
            cf.setAvailability_Yes(false);
                row[9] = "No";
            }
            if (cf.isCertificate_Expired() == true){
                cf.setCertificate_Expired(true);
                row[10] = "Expired";
            }else{
            cf.setCertificate_Expired(false);
                row[10] = "Valid";
            }
            model.addRow(row);
        }
    }
}
